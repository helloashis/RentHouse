<?php

namespace App\Http\Controllers;

use App\District;
use Illuminate\Http\Request;

class DivisionController extends Controller
{


    public function myformAjax($id)
    {
        $district = District::where("division_id",$id)
                    ->get();
        return json_encode($district);
    }


}
