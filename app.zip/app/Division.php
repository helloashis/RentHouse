<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Division extends Model
{
    protected $fillable = [
        'name','slug', 'status',
    ];
    public function district(){
        return $this->hasMany('App\Division', 'division_id');
    }
}
