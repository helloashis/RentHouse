<!doctype html>
<html class="no-js" lang="en">

<head>
    <!-- Basic Page Needs
    ================================================== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Specific Meta
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="glimmer is a modern presentation HTML5 Blog template.">
    <meta name="keywords" content="HTML5, Template, Design, Development, Blog" />
    <meta name="author" content="">

    <!-- Titles
    ================================================== -->
    <title>House Rent with Free</title>

    <!-- Favicons
    ================================================== -->
    <link rel="shortcut icon" href="{{ asset('frontend') }}/images/house-logo.png">
    <link rel="apple-touch-icon" href="{{ asset('frontend') }}/images/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">

    <!-- Custom Font
    ================================================== -->
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i,900,900i%7cPoppins:300,400,500,600,700" rel="stylesheet">  
    
    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="{{ asset('frontend') }}/css/plugins.css">
    <link rel="stylesheet" href="{{ asset('frontend') }}/css/colors.css">
    <link rel="stylesheet" href="{{ asset('frontend') }}/style.css">
    <!-- Modernizr
    ================================================== -->
    <script src="{{ asset('frontend') }}/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>

    
    <div class="container">
        <div class="row">
            <br><br>
            <div class="col-md-3"></div>
            <div class="col-md-6 offset-md-3">
                <!-- log in form -->
                
                <form class="cd-form" style="border:1px solid #1111112e; border-radius:5px;" method="post" action="{{ route('login') }}">
                    @csrf
                    <h3 class="text-center">User Login</h3>
                    <p class="fieldset">
                        <label class="image-replace cd-email" for="signin-email">E-mail</label>
                        <input class="full-width has-padding has-border " value="{{ old('email') }}" name="email" id="signin-email" type="email" placeholder="E-mail">
                        
                        @error('email')
                            <span class="cd-error-message">{{ $message }}</span>
                        @enderror
                    </p>

                    <p class="fieldset">
                        <label class="image-replace cd-password" for="signin-password">Password</label>
                        <input class="full-width has-padding has-border @error('password') is-invalid @enderror" name="password" id="signin-password" type="text"  placeholder="Password">
                        <a href="#0" class="hide-password">Hide</a>
                        @error('password')
                            <span class="cd-error-message">{{ $message }}</span>
                        @enderror
                    </p>

                    <p class="fieldset">
                        <input type="checkbox" name="remember" id="remember-me" {{ old('remember') ? 'checked' : '' }}>
                        <label for="remember-me">Remember me</label>
                        <br>
                        <a class="text-center" style="color:#23ac61" href="{{ route('register') }}">I have no account!</a>
                        
                    </p>   
                    <p class="fieldset">
                        
                        <input class="full-width" type="submit" name="signin" value="Login">
                    </p>
                    <p class="cd-form-bottom-message">
                        
                        <a  style="color:#111" href="{{ route('password.request') }}">Forgot your password?</a>
                    </p>
                </form>
                
            </div>
        </div>
    </div>


    <!-- All The JS Files
    ================================================== --> 
    <script src="{{ asset('frontend') }}/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="{{ asset('frontend') }}/js/plugins.js"></script>
    <script src="{{ asset('frontend') }}/js/main.js"></script> <!-- main-js -->
</body>
</html>